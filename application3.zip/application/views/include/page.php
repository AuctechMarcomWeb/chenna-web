<?php
$this->load->view('include/header');
$this->load->view($page);
$this->load->view('include/footer');
?>